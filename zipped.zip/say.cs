// how to compile and run(use mono): mcs say.cs; mono say.exe
using System;

class Program
{
    static void Main(String[] args)
    {
        Console.WriteLine("일하기 싫다");
    }
}
