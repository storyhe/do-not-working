print u'일하기 싫다'
