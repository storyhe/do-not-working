<?php
	echo "일하기 싫다";
?>
