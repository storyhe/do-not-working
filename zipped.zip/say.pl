print "일하기 싫다\n";
