console.log("일하기 싫다");
