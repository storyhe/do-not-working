# how to compile: swiftc -o say say.swift; ./say
print("일하기 싫다")
